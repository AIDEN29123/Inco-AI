Inco.exe
Command list
These are the commands that you can use to Inco:
Good bye, stop, shut down - shutting down the program
Who is ...
What is ...
Wikipedia
Open Youtube
Open Google
Open Gmail
Open Document from Google
Open Netflix
Open Naver
Open Baidu
Open Discord
Open Github
Open Facebook
Open Twitter
Open Instagram
Open Wikipedia
Open Yandex
Open Yahoo
Open Whatsapp
Open Amazon
Open Live Connect
Open Zoom
Open Spotify
Open Skype
Open Snapchat
Open LinkedIn
Open Pinterest
Open Quora
Open Tiktok
Open Flickr
Open Microsoft Office
Open Reddit
Open VK
Open Twitch
Open BIng
Open Bilibili
Open Mail.ru
Open Duckduckgo
Open Roblox
Open Microsoft Online
Open Microsoft
Open Samsung
Open QQ
Open MSN
Open Docomo
Open Yahoo News
Open Globo
Open Telegram
Open eBay
Open BBC
Open Daum
Open Calculator
Open Notepad
Open Wordpad
Open File Explorer
Weather
Time
Who are you
What can you do
Who made you
Version
Open Stackoverflow
News
Camera, Take a photo
Search
Say
Ask
Joke
What are you doing now
How old are you
What's your name
Email ...